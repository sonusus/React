import React from "react";

function Props(props) {
 
    return(
        <div>{props.data} Megha</div>
    )
}

export default Props